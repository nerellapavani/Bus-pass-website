<?php
session_start();
include 'db_con.php';
$conn = OpenCon();
$q = "SELECT pass_name FROM pass_info where pid= ".$_SESSION['pid'];
$q2 = "SELECT fname,lname,dob,gender,mobile_no,address,photo,email_ID from user_profile natural join credentials where uid=".$_SESSION['uid'];
$result = $conn->query($q);
$result2 = $conn->query($q2);
if (!$result) {
    echo 'Could not run query: ' . mysqli_error($conn);
    exit;
}
if (mysqli_num_rows($result) == 0) {
    echo "No Such pid found";
    exit;
}
if (!$result || mysqli_num_rows($result) == 0) {
    echo "User info not retrieved";
    exit;
}
$result = mysqli_fetch_assoc($result);
$row2 = mysqli_fetch_assoc($result2);
?>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Student Pass Application Form</title>
        <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
        <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
        <!-- Main CSS-->
        <link href="css/formCSS.css" rel="stylesheet" media="all">
    </head>
    <body>
        <div class="page-wrapper font-poppins">
          <div class="row"  style="margin-left: 10px" >
           <div class="col-2" >
             <button class="backbutton" onclick="location.replace('main.php')">Back</button>
           </div>
          </div>
            <div class="wrapper">
                <div class="card card-4">
                    <div class="card-body">
                        <center>
                            <h1 class="title"><?=$result['pass_name']?></h1>
                        </center>
                        <hr>
                        <form id="pass-form" method="POST">
                          <input type="hidden" name="pid" value="<?=$_SESSION['pid']?>" />
                            <div class="row row-space" style="margin:0px 0px 10px;">
                                <h3>Applicant Details</h3>
                            </div>
                            <hr>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            First Name <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="text" name="first-name" value="<?=$row2['fname']?>" required>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Last Name <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="text" name="last-name"value="<?=$row2['lname']?>"  required>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Date Of Birth <span class="required">*</span>
                                        </label>
                                        <div class="input-group-icon">
                                            <input class="input--style-4 js-datepicker" type="text" placeholder="DD/MM/YYYY" name="birthday" max="2021-01-01" value="<?php if(!is_null($row2['dob'])) echo date('d/m/Y', strtotime($row2['dob']));?>" required>
                                            <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                  <div class="input-group">
                                      <label class="label">Gender <span class="required">*</span></label>
                                      <div style="padding-top:10px;">
                                          <label class="radio-container m-r-45">Female
                                              <input type="radio" name="gender" value="Female" <?php if($row2['gender']=='Female') echo 'checked';?> required>
                                              <span class="checkmark"></span>
                                          </label>
                                          <label class="radio-container">Male
                                              <input type="radio" name="gender" value="Male" <?php if($row2['gender']=='Male') echo 'checked';?>>
                                              <span class="checkmark"></span>
                                          </label>
                                          <label class="radio-container">Others
                                              <input type="radio" name="gender" value="Others" <?php if($row2['gender']!='Female' && $row2['gender']!='Male') echo 'checked';?>>
                                              <span class="checkmark"></span>
                                          </label>
                                      </div>
                                  </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            School Name <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="text" name="institution-name" required>
                                    </div>
                                </div>
                            </div>
                            <div class="input-group">
                                <label class="label">
                                    School Address <span class="required">*</span>
                                </label>
                                <input class="input--style-4" type="text" name="institution-address-street" required>
                                <label class="sub-label">Street Address</label>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="institution-address-city" placeholder="Bangalore" disabled="disabled">
                                    <label class="sub-label">City</label>
                                </div>
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="institution-address-postal" required>
                                    <label class="sub-label">Postal/Zip Code</label>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="input-group">
                                <label class="label">
                                    Student Address <span class="required">*</span>
                                </label>
                                <input class="input--style-4" type="text" name="student-address-street" required>
                                <label class="sub-label">Street Address</label>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="student-address-city" placeholder="Bangalore" disabled="disabled">
                                    <label class="sub-label">City</label>
                                </div>
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="student-address-postal" required>
                                    <label class="sub-label">Postal/Zip Code</label>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Grade <span class="required">*</span>
                                        </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="grade" required>
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <option value="1">1 </option>
                                                <option value="2">2 </option>
                                                <option value="3">3 </option>
                                                <option value="4">4 </option>
                                                <option value="5">5 </option>
                                                <option value="6">6 </option>
                                                <option value="7">7 </option>
                                                <option value="8">8 </option>
                                                <option value="9">9 </option>
                                                <option value="10">10 </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Email <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="email" value="<?=$row2['email_ID']?>" name="email" readonly/>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Mobile Number <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="number" value="<?=$row2['mobile_no']?>" name="phone" required>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row row-space" style="margin:0px 0px 10px;">
                                <h3>Pass Details</h3>
                            </div>
                            <hr>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            From <span class="required">*</span>
                                        </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="source" required>
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <label class="sub-label">Source</label>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            To <span class="required">*</span>
                                        </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="destination" required>
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <label class="sub-label">Destination</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">Via 1 </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="via1">
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">Via 2</label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="via2">
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">Pass Start Date<span class="required">*</span></label>
                                        <div class="input-group-icon">
                                            <input class="input--style-4 js-datepicker" type="text" placeholder="DD/MM/YYYY" name="pass-date" min="2021-01-01" required>
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                        </div>
                                    </div>
                               </div>
                     			 </div>
                            <hr>
                            <div class="row row-space" style="margin:0px 0px 10px;">
                                <h3>Document Details</h3>
                            </div>
                            <hr>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Applicant Photo <span class="required">*</span>
                                        </label>
                                        <input type="file" class="input--style-4" name="photo" onchange="previewFile(this);" <?php if($row['photo']=='img/user/no-profile-pic.png') echo 'required';?>>
                                    </div>
                                    <img id="img-upload" src="<?=$row2['photo']?>" style="max-width:200px;max-height:200px;border: 1px solid black;"/>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            School/College Fee Receipt <span class="required">*</span>
                                        </label>
                                        <input type="file" class="input--style-4" data-file-accept="pdf, doc, docx, xls, xlsx, csv, txt, rtf, html, zip, mp3, wma, mpg, flv, avi, jpg, jpeg, png, gif" data-file-maxsize="10854" data-file-minsize="0" data-file-limit="" data-component="fileupload" name="fee-receipt" required>
                                        <label class="sub-label">(Fee Receipt must contain admission number)</label>
                                    </div>
                                </div>
                            </div>
                            <label class="label margin-terms">
                                Terms &Conditions <span class="required">*</span>
                            </label>
                            <input type="checkbox" class="checkbox" id="terms" name="terms" value="agree" required>
                            <label class="checkbox-label" for="terms">
                                Please select to acknowledge that you have read, understood and agreed to the following:<br/>
                                <br/>
                                1. The information furnished by me in the above application is true and correct.
                		<br/>
                                2. The source and destination (via-1 and via-2) selected in the application are the nearest stops to my residence and Educational Institution.
                		<br/>
                                3. I understand that the pass shall allow me to travel only from my residence to my educational institution.
                		<br/>4. I hereby declare that, I am not studying in Residential Institution or pursuing correspondence course which renders ineligible for Student Pass.

                            </label>
                            <hr>
                            <center>
                                <button class="btn btn--radius-2 btn--blue" type="submit">Submit</button>
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script>
            function previewFile(input) {
                var file = $("input[type=file]").get(0).files[0];

                if (file) {
                    var reader = new FileReader();

                    reader.onload = function() {
                        $("#img-upload").attr("src", reader.result);
                    }

                    reader.readAsDataURL(file);
                }
            }
            $(document).ready(function () {
                    $('#pass-form').submit(function(e){
                      e.preventDefault();
                      $.ajax({
                        method: 'post',
                        url: 'profile_edit.php',
                        data: new FormData(this),
                        dataType: 'json',
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(response) {
                           console.log('Profile edited');
                        }
                      });

                      $.ajax({
                        method: 'post',
                        url: 'storeToken.php',
                        data: $(this).serialize(),
                        success: function(response){
                          if(response.startsWith("token.php"))
                             location.replace(response);
                          else console.log(response);
                        }
                      });

                    });
            });
        </script>
        <script src="js/jquery-3.4.1.min.js"></script>
        <script src="vendor/select2/select2.min.js"></script>
        <script src="vendor/datepicker/moment.min.js"></script>
        <script src="vendor/datepicker/daterangepicker.js"></script>
        <!-- Main JS-->
        <script src="js/global.js"></script>
    </body>
</html>
