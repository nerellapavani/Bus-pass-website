<?php
session_start();
include 'db_con.php';
if(!empty($_POST)):
  $conn = OpenCon();
  $route_no = trim($_POST['route_no']);
  $result = $conn->query("SELECT stop_name FROM route_details where route_no='$route_no' order by stop_no");
  $result1 = $conn->query("SELECT source_stop,dest_stop,journey_time,journey_distance from bus_routes where route_no='$route_no'");
  if (!$result || !$result1) {
      echo 'Could not run query: ' . mysqli_error($conn);
      exit;
  }
  if (mysqli_num_rows($result) == 0) {
      echo "Route details not found";
      exit;
  }
  if(mysqli_num_rows($result1) == 0) {
      echo "Route not found";
      exit;
  }
  $row1 = mysqli_fetch_assoc($result1);
?>
<div class="row">
  <div class="col-lg-8 mr-auto ml-auto">
    <div class="row">
      <div class="col-xs-1 mr-auto" >
        <button class="backbutton" onclick="location.replace('main.php')">Back</button>
      </div>
    </div>
    <div class="route-list-wrapper">
      <div class="header">
        <div class="row">
          <div class="col-6">
            <div class="row">
              <h2 class="mr-auto pl-3" style="font-size:20px;"> Route No: <?=$route_no?> </h2>
            </div>
            <div class="row mt-2">
              <span class="mr-auto pl-3" style="font-size:14px;"> <?=$row1['source_stop']?>  to   <?=$row1['dest_stop']?> </span>
            </div>
          </div>
          <div class="col-6">
            <div class="row">
              <span class="ml-auto pr-3" style="font-size:14px;"> Journey Time: <?=$row1['journey_time']?> </span>
            </div>
            <div class="row mt-2">
              <span class="ml-auto pr-3" style="font-size:14px;"> Journey Distance: <?=$row1['journey_distance']?> </span>
            </div>
          </div>
        </div>
      </div>
      <?php
      while ($row = mysqli_fetch_assoc($result)) :
      ?>
      <div class="route-list-content">
        <div class="routeBox">
          <div class="row px-2" style="justify-content:space-between;">
            <div class="col-xs-6">
              <span> <?=$row['stop_name']?> </span>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
      </div>
    </div>
  </div>
</div>


<?php endif;
CloseCon($conn);
?>
