<?php
include 'db_con.php';
if (!empty($_POST)):
    $con = OpenCon();
    if(!empty($_POST['source']) && !empty($_POST['destination'])){
      $source = $_POST['source'];
      $dest = $_POST['destination'];
      $s = "select * from bus_routes where (source_stop = '$source' and dest_stop = '$dest') or (source_stop = '$dest' and dest_stop = '$source')";
    }
    else if(!empty($_POST['route_no'])){
      $routeno = $_POST['route_no'];
      $s = "select * from bus_routes where route_no = '$routeno'";
    }
    else exit("fail");
    $result = mysqli_query($con, $s);
    $num = mysqli_num_rows($result);
    if($num>=1):
      while($row = mysqli_fetch_assoc($result)) :
        ?>
        <div class="routeBox">
          <div class="row px-2" style="justify-content:space-between;">
            <div class="col-xs-6">
              <div class="route-no">  <?=$row['route_no']?> </div>
            </div>
            <div class="col-xs-6">
              <span> <?=$row['source_stop']?>   to   <?=$row['dest_stop']?></span>
            </div>
          </div>
          <div class="row px-2 mt-2" style="justify-content:space-between;">
            <div class="col-xs-6">
               <span>Time: <?=$row['journey_time']?> mins</span><br>
               <span>Distance: <?=$row['journey_distance']?></span>
            </div>
          </div>
        </div>
        <?php
      endwhile;
    else: echo "No Routes Found";
    endif;
    CloseCon($con);
endif;
?>
