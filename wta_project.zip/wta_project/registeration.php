<?php
include 'db_con.php';
session_start();
if (!empty($_POST)){
    $con = OpenCon();

    $fname = trim($_POST["fname"]);
    $lname = trim($_POST["lname"]);
    $gender = $_POST['gender'];
    $pass = trim($_POST["pwd"]);
    $email = trim($_POST["email"]);

    $s = "select * from credentials where email_ID = '$email'";
    $result = mysqli_query($con, $s);
    $num = mysqli_num_rows($result);
    if($num == 1) echo "Email ID Already Been Used";
    else if(strlen($pass)<5) echo "Password must have 5 or more characters.";
    else if(1 === preg_match('~[0-9]~', $fname)) echo "Invaid First Name";
    else {
      $reg1 = "insert into credentials(email_ID,pwd) values('$email','$pass')";
      mysqli_query($con, $reg1) or die('Error, insert query failed: '. mysqli_error($con));
      $uid = $con->insert_id;
      $reg2 = "insert into user_profile(uid,Fname,Lname,gender) values($uid,'$fname','$lname','$gender')";
      mysqli_query($con, $reg2) or die('\nError, insert query failed: '. mysqli_error($con));
      echo "success";
    }
    CloseCon($con);
}
?>
