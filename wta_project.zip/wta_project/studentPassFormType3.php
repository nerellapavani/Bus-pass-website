<?php
session_start();
include 'db_con.php';
$conn = OpenCon();
$q = "SELECT pass_name FROM pass_info where pid= ".$_SESSION['pid'];
$q2 = "SELECT fname,lname,dob,gender,mobile_no,address,photo,email_ID from user_profile natural join credentials where uid=".$_SESSION['uid'];
$result = $conn->query($q);
$result2 = $conn->query($q2);
if (!$result) {
    echo 'Could not run query: ' . mysqli_error($conn);
    exit;
}
if (mysqli_num_rows($result) == 0) {
    echo "No Such pid found";
    exit;
}
if (!$result2 || mysqli_num_rows($result2) == 0) {
    echo "User info not retrieved";
    exit;
}
$result = mysqli_fetch_assoc($result);
$row2 = mysqli_fetch_assoc($result2);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Student Pass Application Form</title>
        <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
        <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
        <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
        <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
        <!-- Main CSS-->
        <link href="css/formCSS.css" rel="stylesheet" media="all">
    </head>
    <body>
        <div class="page-wrapper font-poppins">
          <div class="row"  style="margin-left: 10px" >
           <div class="col-2" >
             <button class="backbutton" onclick="location.replace('main.php')">Back</button>
           </div>
          </div>
            <div class="wrapper">
                <div class="card card-4">
                    <div class="card-body">
                        <center>
                            <h1 class="title"><?=$result['pass_name']?></h1>
                        </center>
                        <hr>
                        <form id="pass-form" method="POST">
                          <input type="hidden" name="pid" value="<?=$_SESSION['pid']?>" />
                            <div class="row row-space" style="margin:0px 0px 10px;">
                                <h3>Applicant Details</h3>
                            </div>
                            <hr>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            First Name <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="text" name="first-name" value="<?=$row2['fname']?>" required>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Last Name <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="text" name="last-name" value="<?=$row2['lname']?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Date Of Birth <span class="required">*</span>
                                        </label>
                                        <div class="input-group-icon">
                                            <input class="input--style-4 js-datepicker" type="text" placeholder="DD/MM/YYYY" name="birthday" max="2021-01-01" value="<?php if(!is_null($row['dob'])) echo date('d/m/Y', strtotime($row['dob']));?>" required>
                                            <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                  <div class="input-group">
                                      <label class="label">Gender <span class="required">*</span></label>
                                      <div style="padding-top:10px;">
                                          <label class="radio-container m-r-45">Female
                                              <input type="radio" name="gender" value="Female" <?php if($row2['gender']=='Female') echo 'checked';?> required>
                                              <span class="checkmark"></span>
                                          </label>
                                          <label class="radio-container">Male
                                              <input type="radio" name="gender" value="Male" <?php if($row2['gender']=='Male') echo 'checked';?>>
                                              <span class="checkmark"></span>
                                          </label>
                                          <label class="radio-container">Others
                                              <input type="radio" name="gender" value="Others" <?php if($row2['gender']!='Female' && $row2['gender']!='Male') echo 'checked';?>>
                                              <span class="checkmark"></span>
                                          </label>
                                      </div>
                                  </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Institution Name <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="text" name="institution-name" required>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Course <span class="required">*</span>
                                        </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="course" required>
                                                <option disabled="disabled" selected="selected">Choose course</option>
                                                <option value="BA">BA </option>
                                                <option value="BACHELOR OF MUSIC">BACHELOR OF MUSIC </option>
                                                <option value="BBA">BBA </option>
                                                <option value="BBS">BBS </option>
                                                <option value="BCA">BCA </option>
                                                <option value="BFA">BFA </option>
                                                <option value="BFSc">BFSc </option>
                                                <option value="BSW">BSW </option>
                                                <option value="INTEGRATED B Sc">INTEGRATED B Sc </option>
                                                <option value="INTEGRATED BA ">INTEGRATED BA </option>
                                                <option value="M Com">M Com </option>
                                                <option value="M Sc">M Sc </option>
                                                <option value="MA">MA </option>
                                                <option value="MSW">MSW </option>
                                                <option value="Advanced Diploma Courses">Advanced Diploma Courses </option>
                                                <option value="ANM">ANM </option>
                                                <option value="B Com LLB">B Com LLB </option>
                                                <option value="B Design">B Design </option>
                                                <option value="B Ed">B Ed </option>
                                                <option value="B PEd">B PEd </option>
                                                <option value="B Pharma">B Pharma </option>
                                                <option value="B Plan">B Plan </option>
                                                <option value="B Sc (Nursing)">B Sc (Nursing) </option>
                                                <option value="BA LLB">BA LLB </option>
                                                <option value="BBA LLB">BBA LLB </option>
                                                <option value="BBT">BBT </option>
                                                <option value="BCJ">BCJ </option>
                                                <option value="BLS">BLS </option>
                                                <option value="BNg">BNg </option>
                                                <option value="BPA ">BPA </option>
                                                <option value="BSc Ed">BSc Ed </option>
                                                <option value="BTA ">BTA </option>
                                                <option value="BTH">BTH </option>
                                                <option value="BTTM ">BTTM </option>
                                                <option value="BVA">BVA </option>
                                                <option value="BVOC">BVOC </option>
                                                <option value="BVSC">BVSC </option>
                                                <option value="CANS">CANS </option>
                                                <option value="CARDIOLOGY TECHNICIAN">CARDIOLOGY TECHNICIAN </option>
                                                <option value="CAT">CAT </option>
                                                <option value="CCARDIO">CCARDIO </option>
                                                <option value="CCTC">CCTC </option>
                                                <option value="CECG">CECG </option>
                                                <option value="CEPT">CEPT </option>
                                                <option value="CHI">CHI </option>
                                                <option value="CHT">CHT </option>
                                                <option value="CLT">CLT </option>
                                                <option value="CMLT">CMLT </option>
                                                <option value="CMXT">CMXT </option>
                                                <option value="COT">COT </option>
                                                <option value="COTT">COTT </option>
                                                <option value="CRA">CRA </option>
                                                <option value="CRI">CRI </option>
                                                <option value="CRUST">CRUST </option>
                                                <option value="CTT">CTT </option>
                                                <option value="NST">NST </option>
                                                <option value="D Ed">D Ed </option>
                                                <option value="D Pharma">D Pharma </option>
                                                <option value="DAM">DAM </option>
                                                <option value="DANS">DANS </option>
                                                <option value="DBBT">DBBT </option>
                                                <option value="DCARDIO">DCARDIO </option>
                                                <option value="DCBR">DCBR </option>
                                                <option value="DCRE">DCRE </option>
                                                <option value="DHY">DHY </option>
                                                <option value="DDIALY">DDIALY </option>
                                                <option value="DDRA">DDRA </option>
                                                <option value="DDTH">DDTH </option>
                                                <option value="DEAIE">DEAIE </option>
                                                <option value="DECG">DECG </option>
                                                <option value="DECSE(MR)">DECSE(MR) </option>
                                                <option value="DENTAL HYGENIST">DENTAL HYGENIST </option>
                                                <option value="DEPT">DEPT </option>
                                                <option value="DFEM">DFEM </option>
                                                <option value="DHA">DHA </option>
                                                <option value="DHFSM">DHFSM </option>
                                                <option value="DHI">DHI </option>
                                                <option value="DHLS">DHLS </option>
                                                <option value="DHLST">DHLST </option>
                                                <option value="DHMCT">DHMCT </option>
                                                <option value="Diploma Courses">Diploma Courses </option>
                                                <option value="DMIT">DMIT </option>
                                                <option value="DMLT">DMLT </option>
                                                <option value="DMRD">DMRD </option>
                                                <option value="DMRT">DMRT </option>
                                                <option value="DMST">DMST </option>
                                                <option value="DMSY">DMSY </option>
                                                <option value="DMXT">DMXT </option>
                                                <option value="DO">DO </option>
                                                <option value="DOA">DOA </option>
                                                <option value="DOM">DOM </option>
                                                <option value="DOT">DOT </option>
                                                <option value="DOTT">DOTT </option>
                                                <option value="DPM">DPM </option>
                                                <option value="DPMT">DPMT </option>
                                                <option value="DPT">DPT </option>
                                                <option value="DREST">DREST </option>
                                                <option value="DRGA">DRGA </option>
                                                <option value="DRTT">DRTT </option>
                                                <option value="DRUST">DRUST </option>
                                                <option value="DSE">DSE </option>
                                                <option value="DSME">DSME </option>
                                                <option value="DSWMECH">DSWMECH </option>
                                                <option value="DTCD">DTCD </option>
                                                <option value="DTE">DTE </option>
                                                <option value="DTT">DTT </option>
                                                <option value="DVR">DVR </option>
                                                <option value="FWT">FWT </option>
                                                <option value="GNM (NURSING)">GNM (NURSING) </option>
                                                <option value="IMA">IMA </option>
                                                <option value="IMSC">IMSC </option>
                                                <option value="Integrated MBA">Integrated MBA </option>
                                                <option value="ITI Courses">ITI Courses </option>
                                                <option value="LLB">LLB </option>
                                                <option value="LLM">LLM </option>
                                                <option value="M Design">M Design </option>
                                                <option value="M Ed">M Ed </option>
                                                <option value="M PED">M PED </option>
                                                <option value="M Pharma">M Pharma </option>
                                                <option value="M Phil ">M Phil </option>
                                                <option value="M Sc (NURSING)">M Sc (NURSING) </option>
                                                <option value="Master in Marketing">Master in Marketing </option>
                                                <option value="Master of International Business">Master of International Business </option>
                                                <option value="MBA">MBA </option>
                                                <option value="MBE ">MBE </option>
                                                <option value="MBS">MBS </option>
                                                <option value="MCA">MCA </option>
                                                <option value="MCJ">MCJ </option>
                                                <option value="MFA">MFA </option>
                                                <option value="MFM">MFM </option>
                                                <option value="MHM">MHM </option>
                                                <option value="MHM">MHM </option>
                                                <option value="MHRD">MHRD </option>
                                                <option value="MMS">MMS </option>
                                                <option value="MPA">MPA </option>
                                                <option value="MPHA">MPHA </option>
                                                <option value="MPHW">MPHW </option>
                                                <option value="MPVA">MPVA </option>
                                                <option value="MRM">MRM </option>
                                                <option value="MRMLV">MRMLV </option>
                                                <option value="MS (Professional)">MS (Professional) </option>
                                                <option value="MTA ">MTA </option>
                                                <option value="PBBSC(NURSING)">PBBSC(NURSING) </option>
                                                <option value="PMOA">PMOA </option>
                                                <option value="Post Graduation Diploma Courses">Post Graduation Diploma Courses </option>
                                                <option value="SDEBM">SDEBM </option>
                                                <option value="SDECN">SDECN </option>
                                                <option value="SDECP">SDECP </option>
                                                <option value="SDEES">SDEES </option>
                                                <option value="SDEIE">SDEIE </option>
                                                <option value="SDETV">SDETV </option>
                                                <option value="UGDPET">UGDPET </option>
                                                <option value="B Arch">B Arch </option>
                                                <option value="B Tech">B Tech </option>
                                                <option value="BE ">BE </option>
                                                <option value="BFT">BFT </option>
                                                <option value="INTEGRATED ENGINEERING B TECH">INTEGRATED ENGINEERING B TECH </option>
                                                <option value="M Arch">M Arch </option>
                                                <option value="M Tech">M Tech </option>
                                                <option value="ME ">ME </option>
                                                <option value="MFT">MFT </option>
                                                <option value="MS (Technical)">MS (Technical) </option>
                                                <option value="MSIT">MSIT </option>
                                                <option value="Ayurveda PG ">Ayurveda PG </option>
                                                <option value="Bachelor of Physio Therapy">Bachelor of Physio Therapy </option>
                                                <option value="BAMS">BAMS </option>
                                                <option value="BDS">BDS </option>
                                                <option value="BHMS">BHMS </option>
                                                <option value="BLT">BLT </option>
                                                <option value="BNYS">BNYS </option>
                                                <option value="BPT">BPT </option>
                                                <option value="BUMS">BUMS </option>
                                                <option value="DA ">DA </option>
                                                <option value="DFM (FORENSIC)">DFM (FORENSIC) </option>
                                                <option value="DM ">DM </option>
                                                <option value="DOMS (OPTHOLMOLOGY)">DOMS (OPTHOLMOLOGY) </option>
                                                <option value="Master of Public Health">Master of Public Health </option>
                                                <option value="MBBS">MBBS </option>
                                                <option value="MD ">MD </option>
                                                <option value="MDS">MDS </option>
                                                <option value="MHA(HEALTH)">MHA(HEALTH) </option>
                                                <option value="MPT">MPT </option>
                                                <option value="MS (Medical)">MS (Medical) </option>
                                                <option value="MVSC ">MVSC </option>
                                                <option value="EVENING">EVENING </option>
                                                <option value="PHD">PHD </option>
                                                <option value="B Com">B Com </option>
                                                <option value="B Sc">B Sc </option>
                                                <option value="BA">BA </option>
                                                <option value="BACHELOR OF MUSIC">BACHELOR OF MUSIC </option>
                                                <option value="BBA">BBA </option>
                                                <option value="BBS ">BBS </option>
                                                <option value="BCA">BCA </option>
                                                <option value="BFA">BFA </option>
                                                <option value="BFSc">BFSc </option>
                                                <option value="BHM">BHM </option>
                                                <option value="BSW">BSW </option>
                                                <option value="INTEGRATED B Sc">INTEGRATED B Sc </option>
                                                <option value="INTEGRATED BA ">INTEGRATED BA </option>
                                                <option value="M Com">M Com </option>
                                                <option value="M Sc">M Sc </option>
                                                <option value="MA">MA </option>
                                                <option value="MSW">MSW </option>
                                                <option value="Advanced Diploma Courses">Advanced Diploma Courses </option>
                                                <option value="ANM">ANM </option>
                                                <option value="B Com LLB">B Com LLB </option>
                                                <option value="B Desgn">B Desgn </option>
                                                <option value="B Ed">B Ed </option>
                                                <option value="B PEd">B PEd </option>
                                                <option value="B Pharma">B Pharma </option>
                                                <option value="B Plan">B Plan </option>
                                                <option value="B Sc (Nursing)">B Sc (Nursing) </option>
                                                <option value="BA LLB">BA LLB </option>
                                                <option value="BBA LLB">BBA LLB </option>
                                                <option value="BBT">BBT </option>
                                                <option value="BCJ">BCJ </option>
                                                <option value="BLS">BLS </option>
                                                <option value="BNg">BNg </option>
                                                <option value="BPA ">BPA </option>
                                                <option value="BSc Ed">BSc Ed </option>
                                                <option value="BTA ">BTA </option>
                                                <option value="BTH ">BTH </option>
                                                <option value="BTTM ">BTTM </option>
                                                <option value="BVA">BVA </option>
                                                <option value="BVOC">BVOC </option>
                                                <option value="BVSC">BVSC </option>
                                                <option value="CANS">CANS </option>
                                                <option value="CARDIOLOGY TECHNICIAN">CARDIOLOGY TECHNICIAN </option>
                                                <option value="CAT">CAT </option>
                                                <option value="CCARDIO">CCARDIO </option>
                                                <option value="CCTC">CCTC </option>
                                                <option value="CECG">CECG </option>
                                                <option value="CEPT">CEPT </option>
                                                <option value="CHI">CHI </option>
                                                <option value="CHT">CHT </option>
                                                <option value="CLT">CLT </option>
                                                <option value="CMLT">CMLT </option>
                                                <option value="CMXT">CMXT </option>
                                                <option value="COT">COT </option>
                                                <option value="COTT">COTT </option>
                                                <option value="CRA">CRA </option>
                                                <option value="CRI">CRI </option>
                                                <option value="CRUST">CRUST </option>
                                                <option value="CTT">CTT </option>
                                                <option value="D Ed">D Ed </option>
                                                <option value="D Pharma">D Pharma </option>
                                                <option value="DAM">DAM </option>
                                                <option value="DANS">DANS </option>
                                                <option value="DBBT">DBBT </option>
                                                <option value="DCARDIO">DCARDIO </option>
                                                <option value="DCBR">DCBR </option>
                                                <option value="DCRE">DCRE </option>
                                                <option value="DDHY">DDHY </option>
                                                <option value="DDIALY">DDIALY </option>
                                                <option value="DDRA">DDRA </option>
                                                <option value="DDTH">DDTH </option>
                                                <option value="DEAIE">DEAIE </option>
                                                <option value="DECG">DECG </option>
                                                <option value="DECSE(MR)">DECSE(MR) </option>
                                                <option value="DENTAL HYGENIST ">DENTAL HYGENIST </option>
                                                <option value="DEPT">DEPT </option>
                                                <option value="DFEM">DFEM </option>
                                                <option value="DHA">DHA </option>
                                                <option value="DHFSM">DHFSM </option>
                                                <option value="DHI">DHI </option>
                                                <option value="DHLS">DHLS </option>
                                                <option value="DHLST">DHLST </option>
                                                <option value="DHMCT">DHMCT </option>
                                                <option value="Diploma Courses">Diploma Courses </option>
                                                <option value="DMIT">DMIT </option>
                                                <option value="DMLT">DMLT </option>
                                                <option value="DMRD">DMRD </option>
                                                <option value="DMRT">DMRT </option>
                                                <option value="DMST">DMST </option>
                                                <option value="DMSY">DMSY </option>
                                                <option value="DMXT">DMXT </option>
                                                <option value="DO">DO </option>
                                                <option value="DOA">DOA </option>
                                                <option value="DOM">DOM </option>
                                                <option value="DOT">DOT </option>
                                                <option value="DOTT">DOTT </option>
                                                <option value="DPM">DPM </option>
                                                <option value="DPMT">DPMT </option>
                                                <option value="DPT">DPT </option>
                                                <option value="DREST">DREST </option>
                                                <option value="DRGA">DRGA </option>
                                                <option value="DRTT">DRTT </option>
                                                <option value="DRUST">DRUST </option>
                                                <option value="DSE">DSE </option>
                                                <option value="DSME">DSME </option>
                                                <option value="DSWMECH">DSWMECH </option>
                                                <option value="DTCD">DTCD </option>
                                                <option value="DTE">DTE </option>
                                                <option value="DTT">DTT </option>
                                                <option value="DVR">DVR </option>
                                                <option value="FWT">FWT </option>
                                                <option value="GNM (NURSING)">GNM (NURSING) </option>
                                                <option value="IMA">IMA </option>
                                                <option value="IMSC">IMSC </option>
                                                <option value="Integrated MBA">Integrated MBA </option>
                                                <option value="ITI Courses">ITI Courses </option>
                                                <option value="LLB">LLB </option>
                                                <option value="LLM">LLM </option>
                                                <option value="M Desgn">M Desgn </option>
                                                <option value="M Ed">M Ed </option>
                                                <option value="M PED">M PED </option>
                                                <option value="M Pharma">M Pharma </option>
                                                <option value="M Phil ">M Phil </option>
                                                <option value="M Sc (NURSING)">M Sc (NURSING) </option>
                                                <option value="Master in Marketing">Master in Marketing </option>
                                                <option value="Master of International Business">Master of International Business </option>
                                                <option value="MBA">MBA </option>
                                                <option value="MBE ">MBE </option>
                                                <option value="MBS">MBS </option>
                                                <option value="MCA">MCA </option>
                                                <option value="MCJ">MCJ </option>
                                                <option value="MFA">MFA </option>
                                                <option value="MFM">MFM </option>
                                                <option value="MHM">MHM </option>
                                                <option value="MHM">MHM </option>
                                                <option value="MHRD">MHRD </option>
                                                <option value="MMS">MMS </option>
                                                <option value="MPA">MPA </option>
                                                <option value="MPHA">MPHA </option>
                                                <option value="MPHW">MPHW </option>
                                                <option value="MPVA">MPVA </option>
                                                <option value="MRM">MRM </option>
                                                <option value="MRMLV">MRMLV </option>
                                                <option value="MS (Professional)">MS (Professional) </option>
                                                <option value="MTA ">MTA </option>
                                                <option value="NST">NST </option>
                                                <option value="PBBSC(NURSING)">PBBSC(NURSING) </option>
                                                <option value="PMOA">PMOA </option>
                                                <option value="Post Graduation Diploma Courses">Post Graduation Diploma Courses </option>
                                                <option value="SDEBM">SDEBM </option>
                                                <option value="SDECN">SDECN </option>
                                                <option value="SDECP">SDECP </option>
                                                <option value="SDEES">SDEES </option>
                                                <option value="SDEIE">SDEIE </option>
                                                <option value="SDETV">SDETV </option>
                                                <option value="UGDPET">UGDPET </option>
                                                <option value="B Arch">B Arch </option>
                                                <option value="B Tech">B Tech </option>
                                                <option value="BE ">BE </option>
                                                <option value="BFT">BFT </option>
                                                <option value="INTEGRATED ENGINEERING B TECH">INTEGRATED ENGINEERING B TECH </option>
                                                <option value="M Arch">M Arch </option>
                                                <option value="M Tech">M Tech </option>
                                                <option value="ME ">ME </option>
                                                <option value="MFT">MFT </option>
                                                <option value="MS (Technical)">MS (Technical) </option>
                                                <option value="MSIT">MSIT </option>
                                                <option value="BHM">BHM </option>
                                                <option value="Pharma D">Pharma D </option>
                                                <option value="BVSc and AH">BVSc and AH </option>
                                                <option value="BPH">BPH </option>
                                                <option value="MPH">MPH </option>
                                                <option value="BHA">BHA </option>
                                                <option value="MLT">MLT </option>
                                                <option value="MIT">MIT </option>
                                                <option value="B Voc">B Voc </option>
                                                <option value="Pharm D Post baccalaureate">Pharm D Post baccalaureate </option>
                                                <option value="Aircraft Maintenance Engineering">Aircraft Maintenance Engineering </option>
                                                <option value="Allied health science">Allied health science </option>
                                            </select>
                                        </div>
                                    </div>
                              </div>
                            </div>
                            <div class="input-group">
                                <label class="label">
                                    Institution Address <span class="required">*</span>
                                </label>
                                <input class="input--style-4" type="text" name="institution-address-street" required>
                                <label class="sub-label">Street Address</label>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="institution-address-city" placeholder="Bangalore" disabled="disabled">
                                    <label class="sub-label">City</label>
                                </div>
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="institution-address-postal" required>
                                    <label class="sub-label">Postal/Zip Code</label>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="input-group">
                                <label class="label">
                                    Student Address <span class="required">*</span>
                                </label>
                                <input class="input--style-4" type="text" name="student-address-street" required>
                                <label class="sub-label">Street Address</label>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="student-address-city" placeholder="Bangalore" disabled="disabled">
                                    <label class="sub-label">City</label>
                                </div>
                                <div class="col-2">
                                    <input class="input--style-4" type="text" name="student-address-postal" required>
                                    <label class="sub-label">Postal/Zip Code</label>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Email <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="email" value="<?=$row2['email_ID']?>" name="email" readonly/>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Mobile Number <span class="required">*</span>
                                        </label>
                                        <input class="input--style-4" type="number" value="<?=$row2['mobile_no']?>" name="phone" required>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row row-space" style="margin:0px 0px 10px;">
                                <h3>Pass Details</h3>
                            </div>
                            <hr>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            From <span class="required">*</span>
                                        </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="source" required>
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <label class="sub-label">Source</label>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            To <span class="required">*</span>
                                        </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="destination" required>
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <label class="sub-label">Destination</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">Via 1 </label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="via1">
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">Via 2</label>
                                        <div class="rs-select2 js-select-simple select--no-search">
                                            <select name="via2">
                                                <option disabled="disabled" selected="selected">Please Select</option>
                                                <?php
                                                $result = $conn->query("SELECT stop_name FROM bus_stops");
                                                if (!$result) {
                                                    echo 'Could not run query: ' . mysqli_error($conn);
                                                    exit;
                                                }
                                                if (mysqli_num_rows($result) == 0) {
                                                    echo "No routes found";
                                                    exit;
                                                }
                                                while ($row = mysqli_fetch_assoc($result)) :
                                                ?>
                                      					<option><?= $row['stop_name']?></option>
                                              <?php endwhile; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">Pass Start Date<span class="required">*</span></label>
                                        <div class="input-group-icon">
                                            <input class="input--style-4 js-datepicker" type="text" placeholder="DD/MM/YYYY" name="pass-date" required>
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                        </div>
                                    </div>
                               </div>
                     			 </div>
                            <hr>
                            <div class="row row-space" style="margin:0px 0px 10px;">
                                <h3>Document Details</h3>
                            </div>
                            <hr>
                            <div class="row row-space">
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            Applicant Photo <span class="required">*</span>
                                        </label>
                                        <input type="file" class="input--style-4" name="photo" onchange="previewFile(this);" <?php if($row['photo']=='img/user/no-profile-pic.png') echo 'required';?>>
                                    </div>
                                    <img id="img-upload" src="<?=$row2['photo']?>" style="max-width:200px;max-height:200px;border: 1px solid black;"/>
                                </div>
                                <div class="col-2">
                                    <div class="input-group">
                                        <label class="label">
                                            School/College Fee Receipt <span class="required">*</span>
                                        </label>
                                        <input type="file" class="input--style-4" data-file-accept="pdf, doc, docx, xls, xlsx, csv, txt, rtf, html, zip, mp3, wma, mpg, flv, avi, jpg, jpeg, png, gif" data-file-maxsize="10854" data-file-minsize="0" data-file-limit="" data-component="fileupload" name="fee-receipt" required>
                                        <label class="sub-label">(Fee Receipt must contain admission number)</label>
                                    </div>
                                </div>
                            </div>
                            <label class="label margin-terms">
                                Terms &Conditions <span class="required">*</span>
                            </label>
                            <input type="checkbox" class="checkbox" id="terms" name="terms" value="agree" required>
                            <label class="checkbox-label" for="terms">
                                Please select to acknowledge that you have read, understood and agreed to the following:<br/>
                                <br/>
                                1. The information furnished by me in the above application is true and correct.
                		<br/>
                                2. The source and destination (via-1 and via-2) selected in the application are the nearest stops to my residence and Educational Institution.
                		<br/>
                                3. I understand that the pass shall allow me to travel only from my residence to my educational institution.
                		<br/>4. I hereby declare that, I am not studying in Residential Institution or pursuing correspondence course which renders ineligible for Student Pass.

                            </label>
                            <hr>
                            <center>
                                <button class="btn btn--radius-2 btn--blue" type="submit">Submit</button>
                            </center>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script>
            function previewFile(input) {
                var file = $("input[type=file]").get(0).files[0];

                if (file) {
                    var reader = new FileReader();

                    reader.onload = function() {
                        $("#img-upload").attr("src", reader.result);
                    }

                    reader.readAsDataURL(file);
                }
            }
            $(document).ready(function () {
                    $('#pass-form').submit(function(e){
                      e.preventDefault();
                      $.ajax({
                        method: 'post',
                        url: 'profile_edit.php',
                        data: new FormData(this),
                        dataType: 'json',
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(response) {
                           console.log('Profile edited');
                        }
                      });

                      $.ajax({
                        method: 'post',
                        url: 'storeToken.php',
                        data: $(this).serialize(),
                        success: function(response){
                          if(response.startsWith("token.php"))
                             location.replace(response);
                          else console.log(response);
                        }
                      });

                    });
            });
        </script>
        <script src="js/jquery-3.4.1.min.js"></script>
        <script src="vendor/select2/select2.min.js"></script>
        <script src="vendor/datepicker/moment.min.js"></script>
        <script src="vendor/datepicker/daterangepicker.js"></script>
        <!-- Main JS-->
        <script src="js/global.js"></script>
    </body>

</html>
<!-- end document-->
