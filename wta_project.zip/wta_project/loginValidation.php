<?php
include "db_con.php";
session_start();
if (!empty($_POST)){
  $email = trim($_POST["email"]);
  $pass = trim($_POST["pwd"]);
  if($email != '' && $pass != '') {
    $con = OpenCon();
    $s = "select uid from credentials where email_ID = '$email' and pwd = '$pass'";
    $result = mysqli_query($con, $s) or die(mysqli_error($con));
    $num = mysqli_num_rows($result);
    if($num == 1) {
      $row = mysqli_fetch_array($result);
      $_SESSION['uid'] = $row['uid'];
      echo "success";
    }
    else echo "fail";
    CloseCon($con);

  }
}
?>
