<?php
include 'db_con.php';
session_start();

if($_POST){
    $con = OpenCon();
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $gender = $_POST['gender'];
    $dob = $_POST["dob"];
    $phone = $_POST["phone"];
    $address = (isset($_POST["address"]))? $_POST["address"]: '';
    $photo = 'img/user/no-profile-pic.png';
    $uploads_dir = 'img/user/';
    $result = '';
    if(!empty($_FILES['photo']['name'])){
         echo
         $file_tmp = $_FILES["photo"]["tmp_name"];
         $file_name = basename($_FILES["photo"]["name"]);
         $tmp = explode('.', $file_name);
         $file_ext=strtolower(end($tmp));
         $photo = $uploads_dir.$_SESSION['uid'].'.'.$file_ext;
         move_uploaded_file($file_tmp, $photo);
    }
    else {
      $photo = $con->query("select photo from user_profile where uid=".$_SESSION['uid']);
      $photo = mysqli_fetch_assoc($res);
    }
    if(!empty($phone)){
      $stmt = $con->prepare('update user_profile set mobile_no=? where uid=?');
      $stmt->bind_param('si',$phone,$_SESSION['uid']);
      $result = $stmt->execute();
      if(!$result) {
            die('Could not update data: ' . mysqli_error($con));
      }
    }

    if(!empty($dob)){
      $stmt = $con->prepare('update user_profile set dob=? where uid=?');
      $stmt->bind_param('si',$dob,$_SESSION['uid']);
      $result = $stmt->execute();
      if(!$result) {
            die('Could not update data: ' . mysqli_error($con));
      }
    }
    $stmt = $con->prepare('update user_profile set fname=?, lname=?, gender=?, address=?,photo=? where uid=?');
    $stmt->bind_param('sssssi',$fname, $lname,$gender,$address,$photo,$_SESSION['uid']);
    $result = $stmt->execute();
    if(!$result) {
          die('Could not update data: ' . mysqli_error($con));
    }
    CloseCon($con);
}

?>
