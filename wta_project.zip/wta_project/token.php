<?php
session_start();
include 'db_con.php';
$conn = OpenCon();
if(isset($_GET['token_id']) && !empty($_GET['token_id'])):
  $tid = $_GET['token_id'];
  $result = $conn->query("SELECT * from token natural join token_pass natural join token_user where token_id='$tid'");
  if (!$result) {
      echo 'Could not run query: ' . mysqli_error($conn);
      exit;
  }
  if (mysqli_num_rows($result) == 0) {
      echo "Token not found ".$tid;
      exit;
  }
  $row = mysqli_fetch_assoc($result);
  $pid = $row['pid'];
  $uid = $row['uid'];
  $row1= mysqli_fetch_assoc($conn->query("SELECT Fname,Lname,mobile_no,email_ID,photo from user_profile natural join credentials where uid='$uid'"));
  $row2 = mysqli_fetch_assoc($conn->query("SELECT pass_name from pass_info where pid='$pid'"));

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Pass-token</title>
  <link rel="stylesheet" type="text/css" href="css/tokenCSS.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Oswald:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body style="font-family: montserrat">
	<div class="container-fluid bg-dark p=0" style="height: 100%;">
    <div class="row"  style="padding: 10px" >
			<div class="col-2" >
				<button class="token-backbutton" onclick="location.replace('main.php')">Back</button>
			</div>
		</div>
		<div class="row" style="height: 10px">
		</div>
        <!--card row-->
		<div class="row">
			<div class="col-sm-2"></div>
			<!-- Card1 -->
			<div class="col-sm-9">
				<div class="token">
					<div class="row">
						<!-- left half of card-text -->
						<div class="col-8">
							<div class="row">
								<div class="col-12">
									<div class="token-title"><?=$row2['pass_name']?>
                    <span class="token-expired">
                      <?php
                          date_default_timezone_set('Asia/Kolkata');
                          $d1 = new DateTime($row['expiry_date']);
                          $d2 = new DateTime("now");
                          if($d1 < $d2) echo '  [Expired]';
                      ?>
                    </span>
                  </div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<p class="token-small-txt">NAME</p>
									<p class="token-name"><?=$row1['Fname'].' '.$row1['Lname']?></p>
								</div>
							</div>
              <?php if($pid>=400): ?>
							<div class="row">
								<div class="col-6">
									<p class="token-small-txt">START</p>
									<div class="token-name"><?=$row['start_stop']?></div>
								</div>
								<div class="col-6">
									<p class="token-small-txt">DEST</p>
									<div class="token-name"><?=$row['end_stop']?></div>
								</div>
							</div>
              <div class="row">
                <?php if($row['via1'] != null):?>
								<div class="col-6">
									<p class="token-small-txt">Via 1</p>
									<div class="token-name">BSK</div>
								</div>
                <?php endif;
                      if($row['via2'] != null):
                ?>
								<div class="col-6">
									<p class="token-small-txt">Via 2</p>
									<div class="token-name">JP Nagar</div>
								</div>
              <?php endif; ?>
							</div>
            <?php else: ?>
              <div class="row">
								<div class="col-6">
									<p class="token-small-txt">MOBILE NO.</p>
									<div class="token-name"><?=$row1['mobile_no']?></div>
								</div>
							</div>
              <div class="row">
								<div class="col-6">
									<p class="token-small-txt">EMAIL ID</p>
									<div class="token-name"><?=$row1['email_ID']?></div>
								</div>
							</div>
            <?php endif; ?>
							<div class="row">
								<div class="col-12">
									<p class="token-small-txt">PERIOD</p>
									<div class="token-name"><?=date('d/m/Y', strtotime($row['issue_date'])).' to '.date('d/m/Y', strtotime($row['expiry_date']))?></div>
								</div>
							</div>
						</div>
						<div class="col-4">
							<div class="row">
								<div class="col-12">
									<div class="token-id"><?=$tid?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<div>
										<img class="token-photo" src="<?=$row1['photo']?>">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  <script src="js/jquery-3.4.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
<?php endif; ?>
