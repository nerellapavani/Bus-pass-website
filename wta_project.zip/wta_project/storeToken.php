<?php
session_start();
include 'db_con.php';
if(!empty($_POST)){
  $conn = OpenCon();
  $pid = $_POST['pid'];
  $uid = $_SESSION['uid'];
  // $uname = $_POST['fname'].' '.$_POST['lname'];
  $result = mysqli_fetch_assoc($conn->query("SELECT duration FROM pass_info where pid='$pid'"));
  $duration = ' + '.$result['duration'].' days';
  $issue_date = date('Y-m-d', strtotime(strtr($_POST['pass-date'], '/', '-')));
  $expiry_date = date('Y-m-d', strtotime($issue_date.$duration));
  $token_id = 0;
  // $data = '';
  if($pid >= 400){
    $source = $_POST['source'];
    $dest = $_POST['destination'];
    if(isset($_POST['via1']) && isset($_POST['via2'])){
      $via1 = $_POST['via1'];
      $via2 = $_POST['via2'];
      $result = $conn->query("INSERT into token(issue_date,expiry_date,start_stop,end_stop,via1,via2) values('$issue_date','$expiry_date','$source','$dest','$via1','$via2')");
    }
    else if(isset($_POST['via1'])){
      $via1 = $_POST['via1'];
      $result = $conn->query("INSERT into token(issue_date,expiry_date,start_stop,end_stop,via1) values('$issue_date','$expiry_date','$source','$dest','$via1')");
    }
    else if(isset($_POST['via2'])){
      $via2 = $_POST['via2'];
      $result = $conn->query("INSERT into token(issue_date,expiry_date,start_stop,end_stop,via2) values('$issue_date','$expiry_date','$source','$dest','$via2')");
    }
    else
      $result = $conn->query("INSERT into token(issue_date,expiry_date,start_stop,end_stop) values('$issue_date','$expiry_date','$source','$dest')");
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($conn);
        exit;
    }
    $token_id = $conn->insert_id;
    $result = $conn->query("INSERT into token_pass values('$token_id','$pid')");
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($conn);
        exit;
    }
    $result = $conn->query("INSERT into token_user values('$token_id','$uid')");
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($conn);
        exit;
    }
    // $studentAddr = $_POST['student-address-street'].' '.$_POST['student-address-city'].' - '.$_POST['student-address-postal'];
    // $institutionAddr = $_POST['institution-address-street'].' '.$_POST['institution-address-city'].' - '.$_POST['institution-address-postal'];
    // $institutionName = $_POST['institution-name'];
    // if($pid == 400){
    //   $grade = $_POST['grade'];
    //   $data = "Name: '$uname' \nStudent Address: '$studentAddr' \nGrade: '$grade'\nSchool Name: '$institutionName'\nSchool Address: '$institutionAddr'\n Source Stop: '$source'\nDestination Stop: '$dest'";
    // }
    // else if($pid == 401){
    //   $course = $_POST['course'];
    //   $data = "Name: '$uname' \nStudent Address: '$studentAddr' \nCollege Name: '$institutionName'\nCollege Course: '$course'\nCollege Address: '$institutionAddr'\n Source Stop: '$source'\nDestination Stop: '$dest'";
    // }
    // else if($pid == 402){
    //   $course = $_POST['course'];
    //   $data = "Name: '$uname' \nStudent Address: '$studentAddr' \nInstitution Name: '$institutionName'\nInstitution Course: '$course'\nInstitution Address: '$institutionAddr'\n Source Stop: '$source'\nDestination Stop: '$dest'";
    // }
  }
  else{
    $result = $conn->query("INSERT into token(issue_date,expiry_date) values('$issue_date','$expiry_date')");
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($conn);
        exit;
    }
    $token_id = $conn->insert_id;
    $result = $conn->query("INSERT into token_pass values('$token_id','$pid')");
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($conn);
        exit;
    }
    $result = $conn->query("INSERT into token_user values('$token_id','$uid')");
    if (!$result) {
        echo 'Could not run query: ' . mysqli_error($conn);
        exit;
    }
  }

  CloseCon($conn);
  echo "token.php?token_id=".$token_id;

}
?>
