<?php
session_start();
include 'db_con.php';
$conn = OpenCon();
$q = "SELECT pid,pass_name FROM pass_info where pid= ".$_SESSION['pid'];
$q2 = "SELECT fname,lname,dob,gender,mobile_no,address,photo,email_ID from user_profile natural join credentials where uid=".$_SESSION['uid'];
$result = $conn->query($q);
$result2 = $conn->query($q2);
if (!$result) {
    echo 'Could not run query: ' . mysqli_error($conn);
    exit;
}
if (mysqli_num_rows($result) == 0) {
    echo "No Such pid found";
    exit;
}
if (!$result || mysqli_num_rows($result) == 0) {
    echo "User info not retrieved";
    exit;
}
$result = mysqli_fetch_assoc($result);
$row = mysqli_fetch_assoc($result2);
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Pass Application Form</title>

    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/formCSS.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper font-poppins">
      <div class="row"  style="margin-left: 10px" >
       <div class="col-2" >
         <button class="backbutton" onclick="location.replace('main.php')">Back</button>
       </div>
     </div>
         <div class="wrapper">
            <div class="card card-4">
                <div class="card-body">
                  <center>
			              <h1 class="title"><?=$result['pass_name']?></h1>
		              </center>
		              <hr>
                  <form id="pass-form" method="POST">
                    <input type="hidden" name="pid" value="<?=$result['pid']?>" />
			              <div class="row row-space" style="margin:0px 0px 10px;">
			               <h3>Applicant Details</h3>
			              </div>
			               <hr>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">First Name <span class="required">*</span></label>
                                    <input class="input--style-4" type="text" name="fname" value="<?=$row['fname']?>" required>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Last Name <span class="required">*</span></label>
                                    <input class="input--style-4" type="text" name="lname" value="<?=$row['lname']?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Date Of Birth <span class="required">*</span></label>
                                    <div class="input-group-icon">
                                        <input class="input--style-4 js-datepicker" type="text" placeholder="DD/MM/YYYY" name="dob" max="2021-01-01" value="<?php if(!is_null($row['dob'])) echo date('d/m/Y', strtotime($row['dob']));?>" required/>
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Gender <span class="required">*</span></label>
                                    <div style="padding-top:10px;">
                                        <label class="radio-container m-r-45">Female
                                            <input type="radio" name="gender" value="Female" <?php if($row['gender']=='Female') echo 'checked';?> required>
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class="radio-container">Male
                                            <input type="radio" name="gender" value="Male" <?php if($row['gender']=='Male') echo 'checked';?>>
                                            <span class="checkmark"></span>
                                        </label>
					                              <label class="radio-container">Others
                                            <input type="radio" name="gender" value="Others" <?php if($row['gender']!='Female' && $row['gender']!='Male') echo 'checked';?>>
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

			<div class="input-group">
				<label class="label">Current Address <span class="required">*</span></label>
                                <input class="input--style-4" type="text" name="address-street" required>
				<label class="sub-label">Street Address</label>
			</div>
			<div class="row row-space">
			    <div class="col-2">
                                <input class="input--style-4" type="text" name="address-city" placeholder="Bangalore" disabled="disabled">
				<label class="sub-label">City</label>
		            </div>
			    <div class="col-2">
                                <input class="input--style-4" type="text" name="address-postal" required>
				<label class="sub-label">Postal/Zip Code</label>
		            </div>
			</div>
			<br><br>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Email <span class="required">*</span></label>
                                    <input class="input--style-4" type="email" value="<?=$row['email_ID']?>" name="email" readonly/>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Mobile Number <span class="required">*</span></label>
                                    <input class="input--style-4" type="number" value="<?=$row['mobile_no']?>" name="phone" required>
                                </div>
                            </div>
                        </div>
			<hr>
			<div class="row row-space" style="margin:0px 0px 10px;">
			  <h3>Pass Details</h3>
			</div>
			<hr>
			 <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Pass Start Date<span class="required">*</span></label>
                                    <div class="input-group-icon">
                                        <input class="input--style-4 js-datepicker" type="text" placeholder="DD/MM/YYYY" name="pass-date" min="2021-01-01" required/>
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                            </div>
			 </div>
			<hr>
			<div class="row row-space" style="margin:0px 0px 10px;">
			  <h3>Document Details</h3>
			</div>
			<hr>
			<div class="row row-space">
			  <div class="col-2">
			    <div class="input-group">
			      <label class="label">Applicant Photo <span class="required">*</span></label>
                    	      <input type="file" class="input--style-4" name="photo" onchange="previewFile(this);" <?php if($row['photo']=='img/user/no-profile-pic.png') echo 'required';?>>
			    </div>
			    <img id="img-upload" src="<?=$row['photo']?>" style="max-width:200px;max-height:200px;border: 1px solid black;"/>
			  </div>
			  <div class="col-2">
			    <div class="input-group">
			      <label class="label">Identity Proof <span class="required">*</span></label>
                    	      <input type="file" class="input--style-4" data-file-accept="pdf, doc, docx, xls, xlsx, csv, txt, rtf, html, zip, mp3, wma, mpg, flv, avi, jpg, jpeg, png, gif" data-file-maxsize="10854" data-file-minsize="0" data-file-limit="" data-component="fileupload" name="fee-receipt" required>
			      <label class="sub-label">Govt. ID (Aadhaar Card, Driving License, Birth certificate, Passport, PAN card) or College/School ID</label>
			    </div>
			  </div>
			</div>

			<label class="label margin-terms">Terms & Conditions <span class="required">*</span></label>
			<input type="checkbox" class="checkbox" id="terms" name="terms" value="agree" required>
			<label class="checkbox-label" for="terms">The information furnished by me in the above application is true and correct.
              		</label><br/><br/>

                        <center><button class="btn btn--radius-2 btn--blue" type="submit">Submit</button></center>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
     function previewFile(input){
        var file = $("input[type=file]").get(0).files[0];

        if(file){
            var reader = new FileReader();

            reader.onload = function(){
                $("#img-upload").attr("src", reader.result);
            }

            reader.readAsDataURL(file);
        }
     }
     $(document).ready(function () {
             $('#pass-form').submit(function(e){
               e.preventDefault();
               $.ajax({
                 method: 'post',
                 url: 'profile_edit.php',
                 data: new FormData(this),
                 dataType: 'json',
                 contentType: false,
                 cache: false,
                 processData: false,
                 success: function(response) {
                    console.log('Profile edited');
                 }
               });

               $.ajax({
                 method: 'post',
                 url: 'storeToken.php',
                 data: $(this).serialize(),
                 success: function(response){
                   if(response.startsWith("token.php"))
                      location.replace(response);
                   else console.log(response);
                 }
               });

             });
     });
    </script>
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body>

</html>
<!-- end document-->
