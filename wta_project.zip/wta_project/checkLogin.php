<?php
session_start();
if(!isset($_SESSION['uid']))
  echo "fail";
else {
  $_SESSION['pid'] = $_POST['pid'];
  echo "success";
}
?>
