<?php
session_start();
include 'db_con.php';
$conn = OpenCon();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Bus Pass Reservation</title>

    <script src="js/jquery-3.4.1.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" />
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="fontawesome/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=PT+Sans:400" rel="stylesheet" />
    <link rel="stylesheet" href="css/style.css" />
    <link type="text/css" rel="stylesheet" href="css/reset.css">
    <link href="css/buspass.css" rel="stylesheet" />
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
</head>

<body>
    <div id="parallax-1" class="parallax-window" data-parallax="scroll" data-image-src="img/bus_header.png">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="logo">
                        <i class="fas fa-bus" style="font-size:5em; margin:30px;"></i>
                        <span class="text-uppercase logo-text"> Bus Pass Reservation  </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="nav-container-outer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <nav id="main-nav d-flex">
                          <ul class="nav nav-tabs" id="main-tabs" role="tablist" style="justify-content:flex-end;">
                                <li class="nav-item">
                                    <a class="nav-link active" href="#routes" id="routes-tab" data-toggle="tab" role="tab" aria-controls="routes" aria-selected="true">Bus Routes <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#passinfo" id="passinfo-tab" data-toggle="tab" role="tab" aria-controls="passes" aria-selected="false">Pass Info</a>
                                </li>
                        			<?php if (!isset($_SESSION['uid'])) : ?>
                        				<li class="nav-item">
                                    <a class="nav-link cd-main-nav__item--signup js-signin-modal-trigger" href="#0" data-signin="login">Login</a>
                                </li>
                              <?php else : ?>
                        				<li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
                                </li>
                              <?php endif; ?>
                          </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-content" id="main-tab-content">
    <div class="tab-pane fade show active container-fluid mt-6 mb-7" id="routes" role="tabpanel" aria-labelledby="routes-tab">
     <div class="row">
	    <div class="col-lg-6 mr-5">
    		<div class="search-form">
    		    <form class="search-route-form" method="post">
              <center><label class="search-title">SEARCH ROUTES</label><center>
              <hr>
    		   <div class="row">
    			  <div class="col-md-5">
    			     <div class="form-group">
    				<span class="form-label">Source</span>
    				<select name="source" class="form-control">
    					<option disabled selected>Bus stop</option>
              <?php

              $result = $conn->query("SELECT stop_name FROM bus_stops");
              if (!$result) {
                  echo 'Could not run query: ' . mysqli_error($conn);
                  exit;
              }
              if (mysqli_num_rows($result) == 0) {
                  echo "No routes found";
                  exit;
              }
              while ($row = mysqli_fetch_assoc($result)) :
              ?>
    					<option><?= $row['stop_name']?></option>
            <?php endwhile; ?>
    				</select>
    			     </div>
    			  </div>
    			  <div class="col-md-5">
    			     <div class="form-group">
    				<span class="form-label">Destination</span>
    				<select name="destination" class="form-control">
    					<option disabled selected>Bus stop</option>
              <?php
              $result = $conn->query("SELECT stop_name FROM bus_stops");
              if (!$result) {
                  echo 'Could not run query: ' . mysqli_error($conn);
                  exit;
              }
              if (mysqli_num_rows($result) == 0) {
                  echo "No routes found";
                  exit;
              }
              while ($row = mysqli_fetch_assoc($result)) :
              ?>
    					<option><?= $row['stop_name']?></option>
            <?php endwhile; ?>
    				</select>
    			     </div>
    			  </div>
    		       </div>
    		       <div class="row">
    			  <div class="col-md-4">
    			     <div class="form-btn">
    				<button type="submit" class="submit-btn">Show Bus Routes</button>
    			     </div>
    			  </div>
    		       </div>
    		    </form>
    		    <center> <h1 style="color:white;margin:30px;">OR</h1></center>
    		    <form class="search-route-form" method="post">
    		       <div class="row">
    			  <div class="col-md-5">
    			      <div class="form-group">
    				 <span class="form-label">Route Number</span>
    				 <select name="route_no" class="form-control">
    					<option disabled selected>Route no.</option>
              <?php
              $result = $conn->query("SELECT route_no FROM bus_routes");
              if (!$result) {
                  echo 'Could not run query: ' . mysqli_error($conn);
                  exit;
              }
              if (mysqli_num_rows($result) == 0) {
                  echo "No routes found";
                  exit;
              }
              while ($row = mysqli_fetch_assoc($result)) :
              ?>
    					<option><?=$row['route_no']?></option>
            <?php endwhile; ?>
    				 </select>
    			      </div>
    			  </div>
    		       </div>
    		       <div class="row">
    			  <div class="col-md-3">
    			      <div class="form-btn">
    				  <button type="submit" class="submit-btn">Show Route</button>
    			      </div>
    			  </div>
    		       </div>
    		    </form>
    		</div>
	    </div>
	    <div class="col-lg-5">
        <div class="route-list-wrapper">
          <div class="header">
            <div class="row">
              <h2> <b>Bus routes</b> </h2>
            </div>
          </div>
          <div class="route-list-content">
            <?php
            if(empty($_POST['submit'])){
              $result = $conn->query("SELECT * FROM bus_routes limit 100");
              if (!$result) {
                  echo 'Could not run query: ' . mysqli_error($conn);
                  exit;
              }
              if (mysqli_num_rows($result) == 0) {
                  echo "No routes found";
                  exit;
              }
            }

            while ($row = mysqli_fetch_assoc($result)) :
            ?>
          <div class="routeBox">
              <div class="row px-2" style="justify-content:space-between;">
                <div class="col-xs-6">
                  <div class="route-no">  <?=$row['route_no']?> </div>
                </div>
                <div class="col-xs-6">
                  <span> <?=$row['source_stop']?>  to   <?=$row['dest_stop']?></span>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
          </div>
        </div>
      </div>
	  </div>
  </div>
  <div class="tab-pane fade container-fluid mt-6 mb-7" id="passinfo" role="tabpanel" aria-labelledby="passinfo-tab">
    <div class="row">
      <div class="col-lg-10">
        <div class="header">
          <center><h2> <b>Bus Passes</b> </h2></center>
        </div>
        <div class="pass-list-content p-2">
          <?php
          $result = $conn->query("SELECT * FROM pass_info order by pid");
          if (!$result) {
              echo 'Could not run query: ' . mysqli_error($conn);
              exit;
          }
          if (mysqli_num_rows($result) == 0) {
              echo "No routes found";
              exit;
          }
          while ($row = mysqli_fetch_assoc($result)) :
          ?>
          <div class="passBox">
            <div class="row mx-1">
              <div class="col-xs-6">
                <div class="pass-name mt-2"><?=$row['pass_name']?> </div>
              </div>
            <form method="post">
              <button class="apply-btn" data-pid="<?=$row['pid']?>" type="submit">Apply</button>
            </form>
            </div>
            <div class="pass-description mx-1">
              <div class="row">
                <div class="col-lg-8">
                  <p><strong>Description:</strong><br><?=$row['details']?></p>
                </div>
                <div class="col-sm-3 ml-auto pr-0 ">
                  <span><b>Eligibility: </b> <?=$row['eligibility']?></span>
                  <span><b>Duration: </b> <?=$row['duration']?> day(s)</span>
                  <span><b>Cost: </b><?=$row['cost']?> Rs.</span>
                </div>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
        </div>
      </div>
  </div>
  </div>
  <?php
  if(isset($_SESSION['uid'])):
      $q = "SELECT * FROM user_profile where uid=".$_SESSION['uid'];
      $result = $conn->query($q);
      $q = "SELECT email_ID from credentials where uid=".$_SESSION['uid'];
      $result2 = $conn->query($q);
      if (!$result || !$result2) {
          echo 'Could not run query: ' . mysqli_error($conn);
          exit;
      }
      $row = mysqli_fetch_assoc($result);
      $row2= mysqli_fetch_assoc($result2);
  ?>
  <div class="tab-pane fade container mt-6 mb-7" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <form method="post" id="profile_form" enctype="multipart/form-data">
              <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <img id="img-upload" src="<?=$row['photo']?>" alt="" style="max-width:200px;max-height:200px;"/>
                            <div class="file btn btn-lg btn-primary">
                                Change Photo
                                <input type="file" id="photo" name="photo" onchange="previewFile(this);" accept=".jpeg, .jpg, .gif, .png, .svg">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="profile-head">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="about-tab" data-toggle="tab" href="#about" role="tab" aria-controls="about" aria-selected="true">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="mypass-tab" data-toggle="tab" href="#mypass" role="tab" aria-controls="mypass" aria-selected="false">My Passes</a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content profile-tab " id="profile-tab-content">
                                    <div class="tab-pane fade show active" id="about" role="tabpanel" aria-labelledby="about-tab">
                                              <div class="row">
                                                    <div class="col-md-3">
                                                        <label>First Name</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input class="form-control" type="text" name="fname" id="fname"  value="<?=$row['fname']?>" >
                                                    </div>
                                                </div>
                                                <div class="row">
                                                      <div class="col-md-3">
                                                          <label>Last Name</label>
                                                      </div>
                                                      <div class="col-md-6">
                                                          <input class="form-control" type="text" name="lname" id="lname" value="<?=$row['lname']?>" >
                                                      </div>
                                                  </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>Email</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input class="form-control" type="email" name="email" id="email"  value="<?=$row2['email_ID']?> " readonly/>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>Gender</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <select class="form-control" name="gender" id="gender" style="height:30px;">
                                                          <option value="Female" <?php if($row['gender']=="Female") echo "selected"; ?>>Female</option>
                                                          <option value="Male" <?php if($row['gender']=="Male") echo "selected"; ?>>Male</option>
                                                          <option value="Others" <?php if($row['gender']=="Others") echo "selected"; ?>>Others</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>Date Of Birth</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input class="form-control" type="date" name="dob" id="dob" max="2021-01-01" value="<?=$row['dob']?>">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>Phone</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <input class="form-control" type="number" name="phone" id="phone" value="<?=$row['mobile_no']?>">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>Address</label>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <textarea class="form-control" rows="3" name="address" id="address" ><?=$row['address']?></textarea>
                                                    </div>
                                               </div>
                                    </div>
                                    <div class="tab-pane fade" id="mypass" role="tabpanel" aria-labelledby="mypass-tab">
                                          <?php
                                          $q = "SELECT token_id,pass_name,expiry_date FROM token natural join token_pass natural join token_user natural join pass_info where uid=".$_SESSION['uid'];
                                          $result = $conn->query($q);

                                          if (!$result) {
                                              echo 'Could not run query: ' . mysqli_error($conn);
                                              exit;
                                          }
                                          while($row = mysqli_fetch_assoc($result)) :
                                          ?>
                                            <div class="passBox">
                                              <div class="row">
                                                <div class="col-sm-2">
                                                  <label><?=$row['token_id']?></label>
                                                </div>
                                                <div class="col-sm-6">
                                                  <label class="pass-name"><?=$row['pass_name']?>
                                                    <span><?php
                                                            date_default_timezone_set('Asia/Kolkata');
                                                            $d1 = new DateTime($row['expiry_date']);
                                                            $d2 = new DateTime("now");
                                                            if($d1 < $d2) echo '  [Expired]';
                                                            else echo '  [Active]';
                                                    ?>
                                                  </span>
                                                  </label>
                                                </div>
                                                <div class="col-sm-2 mt-2">
                                                  <button class="pass-view-btn" data-tokenID="<?=$row['token_id']?>">View</button>
                                                </div>
                                              </div>
                                            </div>
                                          <?php endwhile; ?>
                                      </div>
                                  </div>
                      </div>
                </div>
                <div class="row mt-4">
                  <div class="col-md-2 ml-auto">
                      <input type="submit" id="edit-profile" class="profile-btn" name="profile-edit" value="Edit"/>
                  </div>
                  <div class="col-md-2 ml-2">
                      <button id="log-out" class="profile-btn" style="background-color:black;color:white;" onclick="location.replace('logout.php')" >Logout</button>
                  </div>
                </div>
              </div>
            </form>
        </div>
      <?php endif; ?>
</div>
    <div id="parallax-2" class="parallax-window parallax-window-2" data-parallax="scroll" data-image-src="img/bus_footer.jpg">
        <div class="container-fluid">
        </div>
    </div>

    <!-- modal form -->
    <div class="cd-signin-modal js-signin-modal">
		<div class="cd-signin-modal__container">
			<ul class="cd-signin-modal__switcher js-signin-modal-switcher js-signin-modal-trigger">
				<li><a href="#0" id="login" data-signin="login" data-type="login">Log in</a></li>
				<li><a href="#0" id="signup" data-signin="signup" data-type="signup">New account</a></li>
			</ul>

			<div class="cd-signin-modal__block js-signin-modal-block" id="signin-modal-block" data-type="login"> <!-- log in form -->
				<form class="cd-signin-modal__form" id="signin-modal-form" method="post">
          <center><span id="registeration-success">Registeration Successful! Proceed to input Login credentials</span></center>
					<p class="cd-signin-modal__fieldset">
            <span id="login-error">Username/Password incorrect</span>
						<label class="cd-signin-modal__label cd-signin-modal__label--email cd-signin-modal__label--image-replace" for="signin-email">E-mail</label>
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding cd-signin-modal__input--has-border" id="signin-email" type="email" name="email" placeholder="E-mail">
					</p>

					<p class="cd-signin-modal__fieldset">
						<label class="cd-signin-modal__label cd-signin-modal__label--password cd-signin-modal__label--image-replace" for="signin-password">Password</label>
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding cd-signin-modal__input--has-border" id="signin-password" type="password" name="pwd" placeholder="Password">
						<a href="#0" class="cd-signin-modal__hide-password js-hide-password">Show</a>
					</p>

					<p class="cd-signin-modal__fieldset">
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width" type="submit" value="Login">
					</p>
				</form>

			</div> <!-- cd-signin-modal__block -->

			<div class="cd-signin-modal__block js-signin-modal-block" id="signup-modal-block" data-type="signup"> <!-- sign up form -->
				<form class="cd-signin-modal__form" id="signup-modal-form">
					<p class="cd-signin-modal__fieldset">
						<label class="cd-signin-modal__label cd-signin-modal__label--username cd-signin-modal__label--image-replace" for="signup-fname">First Name</label>
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding cd-signin-modal__input--has-border" id="signup-fname" type="text" name="fname" placeholder="First Name">
						<span class="cd-signin-modal__error">Invalid First name</span>
					</p>

					<p class="cd-signin-modal__fieldset">
						<label class="cd-signin-modal__label cd-signin-modal__label--username cd-signin-modal__label--image-replace" for="signup-lname">Last Name</label>
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding cd-signin-modal__input--has-border" id="signup-lname" type="text" name="lname" placeholder="Last Name">
						<span class="cd-signin-modal__error">Invalid Last Name</span>
					</p>

					<p class="cd-signin-modal__fieldset">
						<label class="cd-signin-modal__label cd-signin-modal__label--gender cd-signin-modal__label--image-replace" for="signup-gender"> Gender </label>
						<select class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding cd-signin-modal__input--has-border" id="signup-gender" name="gender">
							<option selected>Female</option>
							<option>Male</option>
							<option>Others</option>
						</select>

					</p>

					<p class="cd-signin-modal__fieldset">
						<label class="cd-signin-modal__label cd-signin-modal__label--email cd-signin-modal__label--image-replace" for="signup-email">E-mail</label>
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding cd-signin-modal__input--has-border" id="signup-email" type="email" name="email" placeholder="E-mail">
						<span class="cd-signin-modal__error">Please enter a valid email ID</span>
					</p>

					<p class="cd-signin-modal__fieldset">
						<label class="cd-signin-modal__label cd-signin-modal__label--password cd-signin-modal__label--image-replace" for="signup-password">Password</label>
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding cd-signin-modal__input--has-border" id="signup-password" type="password"  name="pwd" placeholder="Password">
						<a href="#0" class="cd-signin-modal__hide-password js-hide-password">Show</a>
						<span class="cd-signin-modal__error">Password does not conform to the set rules</span>
					</p>

					<p class="cd-signin-modal__fieldset">
						<input class="cd-signin-modal__input cd-signin-modal__input--full-width cd-signin-modal__input--has-padding" type="submit" value="Create account">
					</p>
				</form>
			</div> <!-- cd-signin-modal__block -->

			<a href="#0" class="cd-signin-modal__close js-close">Close</a>
		</div> <!-- cd-signin-modal__container -->
	</div> <!-- cd-signin-modal -->


     <script type="text/javascript">

     $(document).ready(function(){

       $('.search-route-form').submit(function(e){
         e.preventDefault();
         $.ajax({
           method: 'post',
           url: 'searchRoutes.php',
           data: $(this).serialize(),
           success: function(response){
             $('.route-list-content').html(response);
           }
         });
       });

       $(document).on('click', '.routeBox', function(){
         $.ajax({
           method: 'post',
           url: 'routeDetails.php',
           data: {'route_no': $(this).find('div.route-no').text()},
           success: function(response){
             $('#routes').html(response);
           }
         });

       });

         $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
             localStorage.setItem('activeTab', $(e.target).attr('href'));
         });
         var activeTab = localStorage.getItem('activeTab');
         if(activeTab){
             $('#main-tabs a[href="' + activeTab + '"]').tab('show');
         }
     });

      $('#signin-modal-form').submit(function(e) {
        e.preventDefault();
        $.ajax({
          method: 'post',
          url: 'loginValidation.php',
          data: $(this).serialize(),
          success: function(response) {
            console.log(response);
            if (response == "success") {
              $('#login-error').hide();
              location.reload();
            }
            else if(response == "fail") $('#login-error').show();
          }
        });
      });

      $('#signup-modal-form').submit(function(e) {
        e.preventDefault();
        $.ajax({
          method: 'post',
          url: 'registeration.php',
          data: $(this).serialize(),
          success: function(response) {
            console.log(response);
            if (response == "success") {
              $('#registeration-success').show();
              document.getElementById("signup-modal-form").reset();
              $('#signin-modal-block').addClass('cd-signin-modal__block--is-selected');
              $('#signup-modal-block').removeClass('cd-signin-modal__block--is-selected');
              $('.cd-signin-modal__switcher a[data-type="login"]').addClass('cd-selected');
              $('.cd-signin-modal__switcher a[data-type="signup"]').removeClass('cd-selected');
            }
          }
        });
      });

      $('.apply-btn').click(function(e) {
        e.preventDefault()
        var pid = e.target.getAttribute('data-pid');
        $.ajax({
          method: 'post',
          url: 'checkLogin.php',
          data: {'pid': pid},
          success: function(response) {
            if(response == 'fail') {
              $('.cd-signin-modal').addClass('cd-signin-modal--is-visible');
              $('#signin-modal-block').addClass('cd-signin-modal__block--is-selected');
              $('#signup-modal-block').removeClass('cd-signin-modal__block--is-selected');
              $('.cd-signin-modal__switcher a[data-type="login"]').addClass('cd-selected');
              $('.cd-signin-modal__switcher a[data-type="signup"]').removeClass('cd-selected');
            }
            else {
              if(pid==400) location.replace('studentPassFormType1.php');
              else if(pid==401) location.replace('studentPassFormType2.php');
              else if(pid==402) location.replace('studentPassFormType3.php');
              else location.replace('ordinaryPassForm.php');
            }
          }
        });
      });

       $("#profile_form").submit(function(e) {
         e.preventDefault();
         if (document.getElementById("edit-profile").value != "Saved!") {
             document.getElementById("edit-profile").setAttribute("value", "Saved!");
             $.ajax({
               method: 'post',
               url: 'profile_edit.php',
               data: new FormData(this),
               contentType: false,
               cache: false,
               processData: false,
               success: function(response) {
                  console.log("Success: "+response);
               },
               error: function(xhr,statusCode,error){
                 console.log("Error: "+error);
               }
             });
         }
       });

     document.querySelectorAll('#profile_form input, #profile_form textarea').forEach(item => {
       item.addEventListener('change', event => {
         document.getElementById("edit-profile").setAttribute("value", "Save Changes");
       })
     });

     $('.pass-view-btn').click(function(e){
       $tid = e.target.getAttribute('data-tokenID');
       console.log($tid);
       location.replace('token.php?token_id='+$tid);
     });

     function contentScroll() {
             $('html,body').animate({
                 scrollTop: $(".container-fluid").offset().top},'slow');

     }

      $(document).ready(function () {
              $('#parallax-1').parallax({ imageSrc: 'img/bus_header.png' });
              $('#parallax-2').parallax({ imageSrc: 'img/bus_footer.jpg' });
              $('select').select2();
      });

      if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
      }

      function previewFile(input) {
            var file = $("input[type=file]").get(0).files[0];

            if (file) {
                var reader = new FileReader();

                reader.onload = function() {
                    $("#img-upload").attr("src", reader.result);
                }

                reader.readAsDataURL(file);
            }
        }
    </script>
    <script src="js/placeholders.min.js"></script>
    <script src="js/modalLogin.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/tooplate-script.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
</body>

</html>
